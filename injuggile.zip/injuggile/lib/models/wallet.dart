class Wallet {
  String currency;
  String amount;

  Wallet({
    this.amount = '',
    this.currency = '',
  });
}
