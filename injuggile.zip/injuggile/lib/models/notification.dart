class Notifications {
  String id;
  String title;
  String type;
  String message;
  String date;

  Notifications({
    this.date,
    this.id,
    this.message,
    this.title,
    this.type,
  });
}
